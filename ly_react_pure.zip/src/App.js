import React from 'react'

// 项目主模块
function App() {
  return (
    <div className="App">
      <h1>This is React App.</h1>
    </div>
  )
}

export default App