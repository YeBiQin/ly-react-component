import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'

// 项目入口文件
ReactDOM.render(<App />, document.getElementById('root'))